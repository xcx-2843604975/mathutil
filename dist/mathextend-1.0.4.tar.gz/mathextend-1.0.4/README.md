# mathutil
[源码 ->](https://github.com/xcx-2843604975/mathutil)

================使用方法================

`from mathutil import *`

`a = Three_dimensional_graphics.Cylinder(Flat_graphics.Circle(radius = 1, pi = Constant.pi15))`

`#定义圆柱`

[其他](https://github.com/xcx-2843604975/mathutil)
